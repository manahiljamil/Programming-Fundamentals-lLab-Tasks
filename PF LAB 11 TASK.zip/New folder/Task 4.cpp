#include <iostream>
using namespace std;

int main() {
   
    const int NUM_ITEMS = 12; 
    const int NUM_MONTHS = 3; 
    double budget[NUM_ITEMS][NUM_MONTHS];

    
    for (int i = 0; i < NUM_ITEMS; i++) {
        for (int j = 0; j < NUM_MONTHS; j++) {
            budget[i][j] = i * 10 + j * 100;
        }
    }

   
    string months[] = 
	{     "January   ",
	      "February  ", 
	      "March     ", 
	      "April     ",
	      "May       ",
	      "June      ", 
	      "July      ", 
	      "August    ",
	      "September ",
		  "October   ", 
		  "November  ",
		  "December  "};
    string items[] = {"Rent", "Electric","Gas"};
            cout << "Yearly Budget:" << endl;
            cout<<  "           Rent   Electric  Gas "<<endl;
    for (int i = 0; i < NUM_ITEMS; i++){
	           cout << months[i] << ": ";
        
    for (int j = 0; j < NUM_MONTHS; j++) {
               cout << budget[i][j]<<"     ";
        }
        cout << endl;
    }

    return 0;
}
