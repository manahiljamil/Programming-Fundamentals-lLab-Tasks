#include<iostream>
using namespace std;
int GreatestValue(){
	int values[20];
	int greatest;
	
	for(int i=0;i<20;i++){
		cout<<"Enter the values to find the greatest value : ";
		cin>>values[i];
		if(values[i]>greatest){
			greatest=values[i];
		}
}
cout<<"The greatest value is = "<<greatest;
}
int main(){
GreatestValue();
return 0;	
}
