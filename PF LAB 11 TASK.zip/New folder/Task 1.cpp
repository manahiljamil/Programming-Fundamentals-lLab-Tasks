#include<iostream>
using namespace std ;
struct Product{
	int Code;
	string Discription;
	char Packaging;
	float Price;
	float Discount;
    float NetPrice;
};
int main(){

Product products[10];
products[0]={1,"Product 1",'L',600.0,1.0};
products[1]={2,"Product 2",'L',300.0,0.0};
products[2]={3,"Product 3",'M',800.0,3.0};
products[3]={4,"Product 4",'S',500.0,2.0};
products[4]={5,"Product 5",'L',200.0,0.0};
products[5]={6,"Product 6",'S',100.0,0.0};
products[6]={7,"Product 7",'S',400.0,1.0};
products[7]={8,"Product 8",'M',600.0,2.0};
products[8]={9,"Product 9",'L',500.0,1.0};
products[9]={10,"Product 10",'M',200.0,0.0};
for(int i=0;i<10;i++){
	if(products[i].Packaging=='L'){
	products[i].NetPrice=products[i].Price -(products[i].Price*products[i].Discount/100);
   	if (	products[i].NetPrice >= 200 && 	products[i].NetPrice <=1000){
		    cout<<"The code of        " <<i+1 <<" is :  " <<(products[i].Code)<<endl;
 			cout<<"The discription of " <<i+1 <<" is :  " <<(products[i].Discription)<<endl;
 			cout<<"The packaging of   " <<i+1 <<" is :  " <<(products[i].Packaging)<<endl;
 			cout<<"The price of       " <<i+1 <<" is :  " <<(products[i].Price)<<endl;
 			cout<<"The discount of    " <<i+1 <<" is :  " <<(products[i].Discount)<<endl;
 			cout<<"The net price of   " <<i+1 <<" is :  " <<(products[i].NetPrice)<<endl<<endl<<endl;
	}
}
}
return 0;
}
    

	
	