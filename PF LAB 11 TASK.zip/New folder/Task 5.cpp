#include <iostream>
using namespace std;
struct Currency{
	string Type;
	double ConversionRate;
};
int main(){
 Currency Rupees={"Rupees",277.53};
 double Amount;
 cout<<"Enter the amount in USD to covert to rupees :";
 cin>>Amount;
 
 double AmountConverted = Amount * Rupees.ConversionRate;
 cout<<	 Amount<<" " <<"USD is equal = "<< AmountConverted<<" "<<"Rupees"<<endl;

return 0;
}


