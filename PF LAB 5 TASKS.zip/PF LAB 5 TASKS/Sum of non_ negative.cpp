    #include<iostream>
    using namespace std;
    int main()
    { int num,sum=0;
    cout<< "Enter the numbers(negative to stop):"<<endl;
	while (true){
	cin>>num;
	if(num<0){
	break;
	}
	sum+=num;
	} 
	cout<<"Sum of non_negative numbers:"<<sum<<endl;
	  return 0;
    }