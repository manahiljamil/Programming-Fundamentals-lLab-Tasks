  #include<iostream>
  using namespace std;
  int main()
  { int num,multiplier;
  cout<<"Which table do you want?"<<endl;
  cin>>num;
  for(multiplier=1 ;multiplier<=10 ;multiplier++)
  {
  cout<<num<<"*"<<multiplier<<"="<<(num*multiplier)<<endl;
  }
  return 0;
  }