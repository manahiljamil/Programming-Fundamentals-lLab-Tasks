  #include<iostream>
  using namespace std;
  int main()
  {
  	int i;
  	const int DAYS =7;
  	double temperatures (DAYS);
	double sum =0 ;
	double average;
  	cout<<"Enter the temperature for each day of the week:"<<endl;
  	for(i=0; i<DAYS;i++)
  	{
  		cout<<"DAY"<<(i+1);
  		cin>>temperatures;
  		sum+=temperatures;
	  }
 average =sum/DAYS;
 cout<<"The average temperature for the week is:" <<average << 	"degrees"<<endl;
 
  return 0;
  }