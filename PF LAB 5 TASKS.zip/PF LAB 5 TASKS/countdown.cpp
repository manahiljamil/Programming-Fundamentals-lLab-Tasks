  #include<iostream>
  using namespace std;
  int main()
  { int num,count;
  cout<<"Enter the number of your choice :"<<endl;
  cin>>num;
  for(count=num ;count>=1 ;count--)
  {
  cout<<count<<endl;
  }
  return 0;
  }