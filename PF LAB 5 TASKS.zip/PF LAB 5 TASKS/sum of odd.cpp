  #include<iostream>
  using namespace std;
  int main()
  { int n , sum=0 ,i=1;
  cout<<"Enter the value:"<<endl;
  cin>>n;
  while(i<=n)
  {
  sum+=i;
  i+=2;
  cout<<"Sum of all odd numbers between 1 and"  <<n<< "is" <<sum <<endl;
  }
  
  return 0;
  }