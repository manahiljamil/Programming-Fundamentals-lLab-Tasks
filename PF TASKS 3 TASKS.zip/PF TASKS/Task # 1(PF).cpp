#include<iostream>
using namespace std;
int main()
{
	float Length,Width,Area,Perimeter;
	cout<<"Enter the length of the reactangle=";
	cin>>Length;
	cout<<"Enter the width of the rectangle =";
	cin>> Width;
	Area = Length*Width;
	Perimeter=2*(Length+Width);
	cout<<"The area of a reactangle="<<Area<<endl;
	cout<<"The perimeter of a rectangle="<<Perimeter;
	
	return 0;
}