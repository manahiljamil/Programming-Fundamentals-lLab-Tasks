#include<iostream>
using namespace std;
int main()
{
	int Number;
	cout<<"Insert the number";
	cin>>Number;	
if(Number%2==0)
{
	cout<<"The given number is even"<<endl;
}
else
{
	cout<<"The given number is odd"<<endl;
}
return 0;
}