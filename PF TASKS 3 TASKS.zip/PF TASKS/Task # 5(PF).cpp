#include <iostream>
using namespace std;
int main()
{
	int Marks;
	cout<<"Enter the marks of the student ";
	cin>> Marks;
	if(Marks>=90)
{
	cout<<"The grade is A"<<endl;
}
else if(Marks>=80)
{
	cout<<"The grade is B"<<endl;
}
else if (Marks>=70)
{
cout<<"The grade is C"<<endl;
}
else if(Marks>=60)
{
	cout<<"The grade is D"<<endl;

}
 else 
 {
cout<<"The grade is F"<<endl;
 }
return 0;
}