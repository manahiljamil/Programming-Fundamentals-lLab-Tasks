#include<iostream>
using namespace std;
int main()
{
	int Celsius, Fahrenheit;
	cout<<"Enter temperature in celsius=";
	cin>>Celsius ,Fahrenheit;
	Fahrenheit = Celsius*9/5+32;
	cout<<"The temperature in Fahrenheit ="<<Fahrenheit;
	return 0;
}