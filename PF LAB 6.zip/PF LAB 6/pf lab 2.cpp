#include<iostream>
using namespace std;
int main()
{
string correctPassword = "manahil123";
    int attempts = 0;
   string inputPassword;

    do {
        cout << "Enter your password: ";
        cin >> inputPassword;
        attempts++;

        if (inputPassword == correctPassword) {
            cout << "Password correct! Access granted."<<endl;
        } else {
            cout << "Password incorrect. Attempts remaining: " << 3 - attempts <<endl;
        }
    } while (inputPassword != correctPassword && attempts < 3);

    if (attempts == 3) {
        cout << "Maximum attempts reached. Access denied."<<endl;
    }

    return 0;
}