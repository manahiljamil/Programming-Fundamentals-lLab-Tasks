#include<iostream>
using namespace std;
int main()
{
int num = 2;

   
    for (int i = 0; i < 7; i++) {
        cout << num <<"  ";
       
        num += 3;
    }

    return 0;
}