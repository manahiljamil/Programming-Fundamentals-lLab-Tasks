#include <iostream>
using namespace std;

int main() {
    int num;
      long long factorial = 1;

    cout << "Enter a positive integer: ";
    cin >> num;

    int i = 1;
    while (i <= num) {
        int j = 1;
        while (j <= 1) { 
            factorial *= i;
            j++;
        }
        i++;
    }

    cout << "Factorial of " << num << " = " << factorial << endl;
    return 0;
}
