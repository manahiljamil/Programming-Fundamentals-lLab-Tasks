#include<iostream>
using namespace std;
int main()
{
   int m=0, n;
   do
   {
	n=0;
	do
     	{
	cout<<"*";
	n++;
    	}
	while( n< m);
	m++;
	cout<<endl;
	}
	while(m<7);
	return 0;
}
