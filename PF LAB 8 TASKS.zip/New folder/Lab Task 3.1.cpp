#include <iostream>
using namespace std;

int main() {
    int i = 1;
    int j;
    while (i <= 9) {
        while ( j<=9) {
            cout <<"*";
            j++;
        }
        cout << endl;
        i++;
    }

    return 0;
}