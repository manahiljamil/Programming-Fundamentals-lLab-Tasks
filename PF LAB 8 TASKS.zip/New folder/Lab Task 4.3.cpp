#include <iostream>
using namespace std;

int main() {
    int num;
    long long factorial = 1;

    cout << "Enter a positive integer: ";
    cin >> num;

    int i = 1;
    do {
        int j = 1;
        do {
            factorial *= i;
            j++;
        } while (j <= 1);  
        i++;
    } while (i <= num);

    cout << "Factorial of " << num << " = " << factorial << endl;
    return 0;
}
