#include<iostream>
using namespace std;
int main()
{
  for(int m=1;m<=7;m++)
   {
  for(int n=1;n<=m;n++)
     {
	cout<<"*";
     }	
   cout<<endl;
   }	
   return 0;
}