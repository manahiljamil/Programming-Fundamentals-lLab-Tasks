#include<iostream>
using namespace std;
int main()
{
	int i=0, j;
	while( i<9 )
	{
	int j=0;
	while( j<9 )
		{
	cout<<"*";
	j++;	
		}
	cout<<endl;
	i++;
	}
	return 0;
}
