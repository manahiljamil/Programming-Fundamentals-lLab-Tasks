#include<iostream>
using namespace std;
int main ()
{
int p,o,i,u,y,t,r,e,w,q;
cout<<"10"<<endl;
cout<<"9"<<endl;
cout<<"8"<<endl;
cout<<"7"<<endl;
cout<<"6"<<endl;
cout<<"5"<<endl;
cout<<"4"<<endl;
cout<<"3"<<endl;
cout<<"2"<<endl;
cout<<"1"<<endl;

	return 0;
}