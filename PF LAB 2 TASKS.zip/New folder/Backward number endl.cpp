#include<iostream>
using namespace std;
int main ()
{
int p,o,i,u,y,t,r,e,w,q;
cout<<"10,9,8,7,6,5,4,3,2,1";

	return 0;
}