#include<iostream>
using namespace std;
int main()
{
int sapid,semester;
string name,course;
sapid=64195;
semester=2;	
name="Manahil Jamil";
course="Programing Fundamentals";
cout<<"Your sap id is:"<<sapid<<endl;
cout<<"Your semester is:"<<semester<<endl;
cout<<"Your name is:"<<name<<endl;
cout<<"Your course is:"<<course;
	return 0;
}