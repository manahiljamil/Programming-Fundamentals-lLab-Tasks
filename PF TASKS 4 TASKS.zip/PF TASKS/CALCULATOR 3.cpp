#include<iostream>
using namespace std;
int main()
{
	char opt;
	int num1,num2;
	cout<<"Enter any two values "<<endl;
	cin>>num1>>num2;
	cout<<"Ente the given operations [+,-,*,%,]:"<<endl;
	cin>>opt;
    switch (opt)
    {
	case '+':
    	cout<<num1+num2;
    	break;
    case '-':
    	cout<<num1-num2;
    	break;
    case '*' :
    	cout<<num1*num2;
    case '%' :
    	cout<<num1/num2;
    	break;
    default:
    	cout<<"invalid opt ";
	}
	
	return 0;
}