#include <iostream>
using namespace std;
int TempOpinion(int & temp){
	if(temp<10){
		cout<<"Cold";
	}
	else if(temp>=20 && temp<=30){
		cout<<"OK";
	}
	else if(temp>30){
		cout<<"Hot";
	}
	else{
		cout<<"Mild";
	}
	return 1;
}
int main(){
	cout<<"   'PASS BY REFERENCE'      "<<endl;
	int temperature;
	cout<<"Enter the temperature : ";
	cin>>temperature;
	 TempOpinion(temperature);
	 
	 return 0;
}