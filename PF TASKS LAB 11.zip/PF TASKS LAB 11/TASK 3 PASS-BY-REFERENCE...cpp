#include <iostream>
using namespace std;
int cubeofinteger(int & a){
	int cube;
	cube=a*a*a;
	cout<<"The cube of the given integer will be :"<<cube<<endl;
	
		return 0;
	}

int main(){
		cout<<"   ' PASS BY REFERENCE'      "<<endl;
	
	int num;
	while(true){
	
	cout<<"Enter the integers to find cube else 0 :";
	cin>>num;
	if(num==0){
	cout<<"             Error:Try again!       ";
	break;
	}
	cubeofinteger(num);
		cout<<endl;
	}

	return 0;
	
}