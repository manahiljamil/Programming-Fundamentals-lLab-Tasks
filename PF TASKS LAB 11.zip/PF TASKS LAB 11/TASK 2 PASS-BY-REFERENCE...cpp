#include <iostream>
using namespace std;
int largestvalue(int & a, int & b, int & c){
	if(a>=b && a>=c){
		return a;
	}
	else if(b>=a && b>=c){
		return b;
	}
	else{
		return c;
	}
}
int main (){
		cout<<"   ' PASS BY REFERENCE'      "<<endl;
	int num1 ;
	int num2 ;
	int num3 ;
	cout<<"Enter three integers: ";
	cin>>num1>>num2>>num3;
	largestvalue(num1,num2,num3);
	cout<<"The largest value is: "<<largestvalue(num1,num2,num3);
}