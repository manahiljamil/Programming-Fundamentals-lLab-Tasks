#include <iostream>
using namespace std;

int swap(int a,int b){
	int temp=a;
	a=b;
	b=temp;
	return 0;
}
int main(){
		cout<<"   ' PASS BY VALUE'      "<<endl;
int num1,num2;
cout<<"Enter first number :";
cin>>num1;
cout<<"Enter second number :";
cin>>num2;
cout<<"Before swapping :"<<endl;
cout<<"Number 1 : "<<num1<<endl;
cout<<"Number 2 : "<<num2<<endl;
swap(num1,num2);
cout<<"After swapping :"<<endl;
cout<<"Number 1 : "<<num1<<endl;
cout<<"Number 2 : "<<num2<<endl;
return 0;	
}